import sqlite3

# Connect to SQLite database (will create the file if it doesn't exist)
con = sqlite3.connect("senroll.db")
print("Database opened successfully")

# Create the table
con.execute("""
    CREATE TABLE IF NOT EXISTS ens (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        name TEXT NOT NULL,
        email TEXT UNIQUE NOT NULL,
        phone TEXT UNIQUE NOT NULL,
        department TEXT NOT NULL
    );
""")

print("Table created successfully")

con.close()
