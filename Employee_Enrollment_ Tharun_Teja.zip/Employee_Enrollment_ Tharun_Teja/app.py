# Title : Employee Enrollment Application

# Authors : Tharun , Hanumateja

# Description : The project Employee Enrollment System is built using the Flask framework for the backend, SQLite for database management



from flask import *
import sqlite3

app = Flask(__name__)

# Home page route
@app.route("/")
def index():
    return render_template("sindex.html")

# Add details page route
@app.route("/add")
def add():
    return render_template("sadd.html")

# Save details (form submission)
@app.route("/savedetails", methods=["POST", "GET"])
def savedeatils():
    msg = "msg"
    if request.method == "POST":
        try:
            # Get data from the form
            name = request.form["name"]
            email = request.form["email"]
            phone = request.form["phone"]
            department = request.form["department"]

            # Check if any field is missing
            if not name or not email or not phone or not department:
                raise ValueError("All fields are required!")

            # Insert data into the database
            with sqlite3.connect("senroll.db") as con:
                cur = con.cursor()
                cur.execute("""
                    INSERT INTO ens (name, email, phone, department)
                    VALUES (?, ?, ?, ?)
                """, (name, email, phone, department))
                con.commit()
                msg = "Your Details have been Successfully Submitted"
        except Exception as e:
            con.rollback()
            msg = f"Error: {e}"  
            print(f"Error: {e}")  
        finally:
            return render_template("ssuccess.html", msg=msg)

# View all details route
@app.route("/view")
def view():
    con = sqlite3.connect("senroll.db")
    con.row_factory = sqlite3.Row  
    cur = con.cursor()
    cur.execute("SELECT * FROM ens")
    rows = cur.fetchall()
    return render_template("sview.html", rows=rows)

# Update department route (new feature)
@app.route("/update", methods=["GET", "POST"])
def update_department():
    msg = ""
    if request.method == "POST":
        try:
            emp_id = request.form["id"]
            new_department = request.form["department"]

            # Ensure both fields are provided
            if not emp_id or not new_department:
                raise ValueError("Please provide both ID and new department!")

            # Update the employee's department in the database
            with sqlite3.connect("senroll.db") as con:
                cur = con.cursor()
                cur.execute("""
                    UPDATE ens
                    SET department = ?
                    WHERE id = ?
                """, (new_department, emp_id))
                con.commit()

                if cur.rowcount == 0:
                    msg = "No employee found with the provided ID."
                else:
                    msg = "Employee department updated successfully."
        except Exception as e:
            con.rollback()
            msg = f"Error: {e}"  
            print(f"Error: {e}")  
    return render_template("supdate.html", msg=msg)

# API route to get all data as JSON
@app.route("/data")
def d1():
    con = sqlite3.connect("senroll.db")
    cur = con.cursor()
    cur.execute("SELECT * FROM ens")
    rows = cur.fetchall()
    return jsonify(rows)

if __name__ == "__main__":
    app.run(debug=True)
